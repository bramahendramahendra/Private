    <div id="footer">
      <p>Copyright &copy; Al- Imran Ahmed</p>
    </div>
  </div>
  <script src="<?=  base_url()?>public/js/jquery-2.1.1.min.js"></script>
  <script src="<?=  base_url()?>public/js/bootstrap.min.js"></script>
</body>
</html>

