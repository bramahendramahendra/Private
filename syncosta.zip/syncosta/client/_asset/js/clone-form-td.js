/*
Author: Tristan Denyer (based on Charlie Griefer's original clone code, and some great help from Dan - see his comments in blog post)
Plugin and demo at http://tristandenyer.com/using-jquery-to-duplicate-a-section-of-a-form-maintaining-accessibility/
Ver: 0.9.4
Date: Aug 25, 2013
*/
$(function () {
    $('#btnAdd').click(function () {
        var num     = $('.clonedInput').length, // Checks to see how many "duplicatable" input fields we currently have
            newNum  = new Number(num + 3),      // The numeric ID of the new input field being added, increasing by 1 each time
            newElem = $('#entry' + num).clone().attr('id', 'entry' + newNum).fadeIn('slow'); // create the new element via clone(), and manipulate it's ID using newNum value
    /*  This is where we manipulate the name/id values of the input inside the new, cloned element
        Below are examples of what forms elements you can clone, but not the only ones.
        There are 2 basic structures below: one for an H2, and one for form elements.
        To make more, you can copy the one for form elements and simply update the classes for its label and input.
        Keep in mind that the .val() method is what clears the element when it gets cloned. Radio and checkboxes need .val([]) instead of .val('').
    */
        // H2 - section (untuk label nomor)
        newElem.find('.heading-reference').attr('id', 'ID' + newNum + '_reference').attr('name', 'ID' + newNum + '_reference').html('Pertanyaan : ' + newNum);

        // soal pertanyaan - select
        newElem.find('.lpertanyaan').attr('for', 'ID' + newNum + '_ipertanyaan');
        newElem.find('.inputper').attr('id', 'ID' + newNum + '_ipertanyaan').attr('name', 'ID' + newNum + '_ipertanyaan').attr('disabled','disabled').val('');

         // dropdown jenis jawaban
        // newElem.find('.label_ttl').attr('for', 'ID' + newNum + '_title');
        newElem.find('.select_ttl').attr('id', 'ID' + newNum + '_title').attr('name', 'ID' + newNum + '_title').attr('disabled','disabled').attr('style','text-align:left').val("");

        // div checkbox 
        newElem.find('.divjcheckbox').attr('id', 'ID' + newNum + '_jcheckbox').attr('name', 'ID' + newNum + '_jcheckbox').val([]);
        newElem.find('.input_checkboxitem').attr('id', 'ID' + newNum + '_checkboxitem').attr('name', 'ID' + newNum + '_checkboxitem').attr('disabled','disabled').val('[]');
        newElem.find('.text_checkboxitem').attr('id', 'ID' + newNum + '_textcheckboxitem').attr('name', 'ID' + newNum + '_textcheckboxitem').attr('disabled','disabled').val('');

         // div textinput 
        newElem.find('.divtextbox').attr('id', 'ID' + newNum + 'jtextbox').attr('name', 'ID' + newNum + 'jtextbox').val([]);
        newElem.find('.textboxitem').attr('id', 'ID' + newNum + '_text_box').attr('name', 'ID' + newNum + '_text_box').val('');

        // // Skate - radio
        // newElem.find('.label_radio').attr('for', 'ID' + newNum + '_radioitem');
        // newElem.find('.input_radio').attr('id', 'ID' + newNum + '_radioitem').attr('name', 'ID' + newNum + '_radioitem').val([]);

        // // Email - text
        // newElem.find('.label_email').attr('for', 'ID' + newNum + '_email_address');
        // newElem.find('.input_email').attr('id', 'ID' + newNum + '_email_address').attr('name', 'ID' + newNum + '_email_address').val('');

        // // Twitter handle (for Bootstrap demo) - append and text
        // newElem.find('.label_twt').attr('for', 'ID' + newNum + '_twitter_handle');
        // newElem.find('.input_twt').attr('id', 'ID' + newNum + '_twitter_handle').attr('name', 'ID' + newNum + '_twitter_handle').val('');

    // Insert the new element after the last "duplicatable" input field
        $('#entry' + num).after(newElem);
        $('#ID' + newNum + '_title').focus();

    // Enable the "remove" button. This only shows once you have a duplicated section.
        $('#btnDel').attr('disabled', false);

    // Right now you can only add 4 sections, for a total of 5. Change '5' below to the max number of sections you want to allow.
        if (newNum == 5)
        $('#btnAdd').attr('disabled', true).prop('value', "You've reached the limit"); // value here updates the text in the 'add' button when the limit is reached 
    });

    $('#btnDel').click(function () {
    // Confirmation dialog box. Works on all desktop browsers and iPhone.
        if (confirm("Apakah Anda Yakin Ingin Menghapus Pertanyaan Diatas ? "))
            {
                // var num = $('.clonedInput').length; => ini yg asli
                var num = 4;
                // how many "duplicatable" input fields we currently have
                $('#entry' + num).slideUp('slow', function () {$(this).remove();
                // if only one element remains, disable the "remove" button
                    if (num -1 === 1)
                $('#btnDel').attr('disabled', true);
                // enable the "add" button
                $('#btnAdd').attr('disabled', false).prop('value', "Tambah Pertanyaan");});
            }
        return false; // Removes the last section you added
    });
    // Enable the "add" button
    $('#btnAdd').attr('disabled', false);
    // Disable the "remove" button
    $('#btnDel').attr('disabled', true);

 
});

   // ini untuk show hide select box
    $(document).on('change', '.select_ttl',function () {
        var $this = $(this), $part = $this.closest('.col-sm-10');
        $part .find('.tmp_item').hide();
        if ($(this).val() != "") {
            $part.find('.' + $(this).val().toLowerCase() + '_tampil').show();
        }
    });